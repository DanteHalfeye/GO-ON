﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento : MonoBehaviour
{
    public Vector3 Velocidad;
        void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            GetComponent<Rigidbody>().velocity = -Velocidad;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            GetComponent<Rigidbody>().velocity = Velocidad;
        }
        else
        {
            GetComponent<Rigidbody>().velocity = Vector3.zero;
        }

    }
}
