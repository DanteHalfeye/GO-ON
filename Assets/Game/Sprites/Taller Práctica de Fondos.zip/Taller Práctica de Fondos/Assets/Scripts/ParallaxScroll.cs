﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxScroll : MonoBehaviour
{
    public float ParallaxValue = 1;
    private Transform CamaraPrincipal;
    private Vector3 UltimaPosCamara;

    private float tamañoTexturaX;
        
        void Start()
    {
        CamaraPrincipal = Camera.main.transform;

        Sprite fondo = GetComponent<SpriteRenderer> ().sprite;
        Texture2D textura2D = fondo.texture;

        tamañoTexturaX = textura2D.width / fondo.pixelsPerUnit;
        Debug.Log(tamañoTexturaX);
    }

    // Update is called once per frame
    void Update()
    {
        float diferenciaX = (CamaraPrincipal.position.x - UltimaPosCamara.x) * ParallaxValue;

        transform.position += new Vector3(diferenciaX, 0, 0);

        UltimaPosCamara = CamaraPrincipal.position;

        if(Mathf.Abs(CamaraPrincipal.position.x - transform.position.x) >= tamañoTexturaX)
        {
            transform.position = new Vector3(CamaraPrincipal.position.x, transform.position.y, transform.position.z);
        }
    }
}
